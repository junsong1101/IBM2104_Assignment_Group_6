<?php
    if ( isset($_GET['success']) && $_GET['success'] == 1 ) {
        include('alert.php');
         echo'<div class="alert">
          <span class="closebtn">&times;</span>  
          <strong>Fail!</strong> Please login to proceed!
        </div>';
    }
    if ( isset($_GET['success']) && $_GET['success'] == 2 ) {
        include('alert.php');
         echo'<div class="alert success">
          <span class="closebtn">&times;</span>  
          <strong>Success!</strong> Your account has logged out!
        </div>';
    }
    if ( isset($_GET['success']) && $_GET['success'] == 3 ) {
        include('alert.php');
         echo'<div class="alert success">
          <span class="closebtn">&times;</span>  
          <strong>Success!</strong> Account Successfully Registered! Please Login to continue....
        </div>';
    }
    if ( isset($_GET['success']) && $_GET['success'] == 4 ) {
        include('alert.php');
         echo'<div class="alert">
          <span class="closebtn">&times;</span>  
          <strong>Fail!</strong> Fail to Create New Account! Please try again later....
        </div>';
    }
    if ( isset($_GET['success']) && $_GET['success'] == 5 ) {
        include('alert.php');
         echo'<div class="alert">
          <span class="closebtn">&times;</span>  
          <strong>Fail!</strong> Password Error! Please try and use another combination of password.
        </div>';
    }
    if ( isset($_GET['success']) && $_GET['success'] == 6 ) {
        include('alert.php');
         echo'<div class="alert">
          <span class="closebtn">&times;</span>  
          <strong>Fail!</strong> Wrong Email or Password Entered! Please try again.
        </div>';
    }
    if(isset($_POST['email']) && isset($_POST['password'])){
        
        //database configuration
        include("database-config.php");
        
        //escape special characters
        $email = mysqli_real_escape_string($conn, $_POST['email']);
        $password = mysqli_real_escape_string($conn, $_POST['password']);
        
        $sql = "SELECT * FROM tbl_user WHERE user_email = '$email'";
        $result = mysqli_query($conn, $sql);
        if(mysqli_num_rows($result) >0){
            //email founded
            $row = mysqli_fetch_assoc($result);
            $hash = $row['user_password'];
            
            //password verification
            if (password_verify($password, $hash)) {

                //set user session
                session_start();
                $_SESSION['user_name'] = $row['user_name'];
                $_SESSION['user_type'] = $row['user_type'];
                $_SESSION['user_email'] = $row['user_email'];
                $_SESSION['user_id'] = $row['user_id'];
                $_SESSION['user_contact'] = $row['user_contact'];

                if($row['user_type'] == "admin"){
                    $conn->close();
                    header("Location: index.php?success=3");
                    exit();
                }
                
                //close database and direct user
                $conn->close();
                header("Location: index.php?success=3");
                exit();
                
            }else {
                //password not match
                $conn->close();
                header("Location: login.php?success=6");
                exit();
            }
            
        }else{
            //email not match
            $conn->close();
            header("Location: login.php?sucess=6");
            exit();
        }
    }else{
        //form not submitted
?>
<!doctype html>
<html lang="en">

  <head>
    <title>Login</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700;900&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="fonts/icomoon/style.css">

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.fancybox.min.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">
    <link rel="stylesheet" href="css/aos.css">

    <!-- MAIN CSS -->
    <link rel="stylesheet" href="css/style.css">
      <style>
        .fb {
          background-color: #3B5998;
          color: white;
        }

        .twitter {
          background-color: #55ACEE;
          color: white;
        }

        .google {
          background-color: #dd4b39;
          color: white;
        }
        .col {
          float: left;
          width: 100%;
          margin: auto;
          padding: 0 10px;
          margin-top: 6px;
            text-align: center;
        }
        input,
        .btn {
          width: 100%;
          padding: 12px;
          border: none;
          border-radius: 4px;
          margin: 5px 0;
          opacity: 0.85;
          display: inline-block;
          font-size: 17px;
          line-height: 20px;
          text-decoration: none; /* remove underline from anchors */
        }
        .savebtn {
              background-color: #007bff; 
              float: left;
              width: 100%;
              border: none;
              color: white;
              margin: 8px 0;
              padding: 14px 20px;
          }
          .image{
              opacity: 1;
              display: block;
              width: 100%;
              height: auto;
              margin: auto;
              transition:  .5 ease;
              backface-visibility: hidden;
              cursor: pointer;
          }
    </style>
  </head>

  <body>

    
    <div class="site-wrap" id="home-section">

      <div class="site-mobile-menu site-navbar-target">
        <div class="site-mobile-menu-header">
          <div class="site-mobile-menu-close mt-3">
            <span class="icon-close2 js-menu-toggle"></span>
          </div>
        </div>
        <div class="site-mobile-menu-body"></div>
      </div>

<?php
    include('header.php');
?>
        
        <section class="ftco-section" style="margin-top: 50px;">
    	<div class="container">
            <form action="login.php" method="post"  enctype="multipart/form-data">
                <div class="row">
                    <div class="col-lg-6 mb-5 ftco-animate">
                        <div class="imgcontainer">
                          <img class="image" id="upload" src="images/login.jpg">
                        </div>
                        
                    </div>
                    <div class="col-lg-6  pl-md-5 ftco-animate">
                        <div class="container" style="padding:16px;">
                            <h1 style="margin-bottom: 20px;">Login</h1>
                            <label for="email"><b>Email</b></label>
                            <input type="text" name="email" class="form-control" placeholder="Enter Your Email Address" required>

                            <label for="password"><b>Password</b></label>
                            <input type="password" class="form-control" placeholder="Enter Password" name="password" required> 
                            
                            <button type="submit" class="savebtn">Login</button>
                            <div class="container">
                              <span class="psw">No account? <a href="register.php">Sign Up here!</a></span>
                            </div>
                            <div class="col">
                                <p>or</p>  
                                <hr class="solid">
                                <p>Login with:</p>
                                <a href="#" class="fb btn">
                                    <i class="fa fa-facebook fa-fw"></i> Facebook
                                </a>
                                <a href="#" class="twitter btn">
                                    <i class="fa fa-twitter fa-fw"></i> Twitter
                                </a>
                                <a href="#" class="google btn"><i class="fa fa-google fa-fw">
                                  </i> Google+
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
    	</div>
    </section>
        
<?php
    include('footer.php');
?>

    </div>

    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/jquery.sticky.js"></script>
    <script src="js/jquery.waypoints.min.js"></script>
    <script src="js/jquery.animateNumber.min.js"></script>
    <script src="js/jquery.fancybox.min.js"></script>
    <script src="js/jquery.easing.1.3.js"></script>
    <script src="js/bootstrap-datepicker.min.js"></script>
    <script src="js/aos.js"></script>

    <script src="js/main.js"></script>

  </body>

</html>
<?php } ?>