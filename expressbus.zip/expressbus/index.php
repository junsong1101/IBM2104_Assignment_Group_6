<?php
    if(!isset($_SESSION)){
           session_start();   
    }
    include('check-login.php');
    if ( isset($_GET['success']) && $_GET['success'] == 1 ) {
        include('alert.php');
         echo'<div class="alert">
          <span class="closebtn">&times;</span>  
          <strong>Fail!</strong> Please login to proceed!
        </div>';
    }
    if ( isset($_GET['success']) && $_GET['success'] == 2 ) {
        include('alert.php');
         echo'<div class="alert">
          <span class="closebtn">&times;</span>  
          <strong>Fail!</strong> Error during Checkout! Please try again....
        </div>';
    }
    if ( isset($_GET['success']) && $_GET['success'] == 3 ) {
        include('alert.php');
         echo'<div class="alert success">
          <span class="closebtn">&times;</span>  
          <strong>Success!</strong> Successfully logged in as '; echo $_SESSION['user_name']; echo' 
        </div>';
    }
    if ( isset($_GET['success']) && $_GET['success'] == 4 ) {
        include('alert.php');
         echo'<div class="alert">
          <span class="closebtn">&times;</span>  
          <strong>Fail!</strong> Fail to submit messages! Please try again....
        </div>';
    }
    if ( isset($_GET['success']) && $_GET['success'] == 5 ) {
        include('alert.php');
         echo'<div class="alert success">
          <span class="closebtn">&times;</span>  
          <strong>Success!</strong> Successful submit your messages! Thank you for your sincerity....
        </div>';
    }
?>
<!doctype html>
<html lang="en">

  <head>
    <title>XpressBus Home</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700;900&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="fonts/icomoon/style.css">

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.fancybox.min.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">
    <link rel="stylesheet" href="css/aos.css">

    <!-- MAIN CSS -->
    <link rel="stylesheet" href="css/style.css">
      <style>
          .trip-form{
              background-color: white;
              opacity: 0.9;
          }
          h3{
              font-weight: 600;
          }
      </style>
  </head>

  <body>

    
    <div class="site-wrap" id="home-section">

      <div class="site-mobile-menu site-navbar-target">
        <div class="site-mobile-menu-header">
          <div class="site-mobile-menu-close mt-3">
            <span class="icon-close2 js-menu-toggle"></span>
          </div>
        </div>
        <div class="site-mobile-menu-body"></div>
      </div>

<?php
    include('header.php');
?>
      
      
  <div class="hero" style="background-image: url('images/homebg.jpg');">
        
        <div class="container">
          <div class="row align-items-center justify-content-center">
            <div class="col-lg-10">
              
              <form action="reservation.php" method="post" autocomplete="off" enctype="multipart/form-data" class="trip-form">
                
                <div class="row align-items-center">
                  <div class="mb-3 mb-md-0 col-md-6">
                      <div class="row">
                          <div class="mb-3 mb-md-0 col-md-6">
                            <label for="departure"><b>From: </b></label>
                            <select name="from" class="form-control" required>
                            <?php
                                include('database-config.php');
                                $sql = "SELECT * FROM tbl_area_location WHERE status = '1'";
                                $result = mysqli_query($conn, $sql);
                                if(mysqli_num_rows($result) > 0){
                                    while($row = mysqli_fetch_assoc($result)){
                            ?>
                                        <option class="dd" value="<?php echo $row['area_name']?>"><?php echo $row['area_name']?></option>
                            <?php
                                    }
                                }
                                mysqli_close($conn);
                            ?>        
                            </select>
                          </div>
                          <div class="mb-3 mb-md-0 col-md-6">
                            <label for="arrival"><b>To: </b></label>
                            <select name="to" class="form-control" required>
                            <?php
                                include('database-config.php');
                                $sql = "SELECT * FROM tbl_area_location WHERE status = '1' ORDER BY area_id DESC";
                                $result = mysqli_query($conn, $sql);
                                if(mysqli_num_rows($result) > 0){
                                    while($row = mysqli_fetch_assoc($result)){
                            ?>
                                        <option value="<?php echo $row['area_name']?>"><?php echo $row['area_name']?></option>
                            <?php
                                    }
                                }
                                mysqli_close($conn);
                            ?>  
                            </select>
                          </div>
                      </div>
                    </div>
                    <div class="mb-3 mb-md-0 col-md-6">
                      <div class="row">
                          <div class="mb-3 mb-md-0 col-md-6">
                            <div class="form-control-wrap">
                              <label for="departure"><b>Departure: </b></label>
                              <input type="text" name="onward" id="cf-3" placeholder="Date" class="form-control datepicker px-3" required>
                              <span class="icon icon-date_range"></span>

                            </div>
                          </div>
                          <div class="mb-3 mb-md-0 col-md-6">
                            <label for=""><b></b></label>
                        <input type="submit" value="Search" class="btn btn-primary btn-block py-3">
                          </div>
                      </div>
                    </div>
                </div>           
                </form>
            </div>
          </div>
        </div>
      </div>


      <div class="site-section">
        <div class="container">
          <h2 class="section-heading"><strong>How it works?</strong></h2>
          <p class="mb-5">Easy steps to get you started</p>    

          <div class="row mb-5">
            <div class="col-lg-4 mb-4 mb-lg-0">
              <div class="step">
                <span>1</span>
                <div class="step-inner">
                  <span class="number text-primary">01.</span>
                  <h3>Choose Destinations</h3>
                  <p>Select the Departure and Arrival Locations based on dates.</p>
                </div>
              </div>
            </div>
            <div class="col-lg-4 mb-4 mb-lg-0">
              <div class="step">
                <span>2</span>
                <div class="step-inner">
                  <span class="number text-primary">02.</span>
                  <h3>Fill up reservation form</h3>
                  <p>Fill your personal details and select the seats of your choice! </p>
                </div>
              </div>
            </div>
            <div class="col-lg-4 mb-4 mb-lg-0">
              <div class="step">
                <span>3</span>
                <div class="step-inner">
                  <span class="number text-primary">03.</span>
                  <h3>Payment</h3>
                  <p>Pay with credit / debit card, online banking or cash.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <div class="site-section">
        <div class="container">
          <div class="row align-items-center">
            <div class="col-lg-7 text-center order-lg-2">
              <div class="img-wrap-1 mb-5">
                <img src="images/bus999.jpg" alt="Image" class="img-fluid">
              </div>
            </div>
            <div class="col-lg-4 ml-auto order-lg-1">
              <h3 class="mb-4 section-heading"><strong>How do we make it happen?</strong></h3>
              <p class="mb-5">Our core value is to constantly provide the best service for all of our customer. We offer one of the most hassle-free booking experience in the industry. A few clicks away and you are ready to travel to your favorite destination. Booking has never been easier with ExpressBus! Just search, book and go!</p>
              
              <p><a href="reservation.php" class="btn btn-primary">Book now</a></p>
            </div>
          </div>
        </div>
      </div>

      

    <div class="site-section bg-light">
      <div class="container">
        <div class="row">
          <div class="col-lg-7">
            <h2 class="section-heading"><strong>Partner Companies</strong></h2>
            <p class="mb-5">We are currently collaborating with 50+ partner companies.</p>    
          </div>
        </div>
          <div class="row">
    
<?php
    include('database-config.php');

    $sql = "SELECT * FROM tbl_bus ";
    $result = mysqli_query($conn, $sql);

    if ($result->num_rows > 0) {
        while($row = mysqli_fetch_assoc($result)) {
?>                
          <div class="col-md-6 col-lg-4 mb-4">

            <div class="listing d-block  align-items-stretch">
              <div class="listing-img h-100 mr-4">
                <img src="<?php 
                        if($row['bus_image'] != null){
                            echo $row['bus_image'];
                        }else{
                            ?>images/defaultImg.png<?php
                        } ?>" alt="Image" class="img-fluid">
              </div>
              <div class="listing-contents h-100">
                <h3><?php echo $row['bus_name']; ?></h3>
                <div class="rent-price">
                  <strong><?php echo $row['bus_description']; ?></strong><span class="mx-1">/</span>trip
                </div>
                <div class="d-block d-md-flex mb-3 border-bottom pb-3">
                  <div class="listing-feature pr-4">
                    <span class="caption">Number Plate:</span>
                    <span class="number"><?php echo $row['bus_number_plate']; ?></span>
                  </div>
                  <div class="listing-feature pr-4">
                    <span class="caption">AC:</span>
                    <span class="number"><?php if($row['bus_ac'] == "y"){ echo "yes";}else{echo "no";} ?></span>
                  </div>
                  <div class="listing-feature pr-4">
                    <span class="caption">Passenger:</span>
                    <span class="number"><?php echo $row['bus_seats']; ?></span>
                  </div>
                </div>
                <div>
                  <p><a href="reservation.php" class="btn btn-primary btn-sm">Book Now</a></p>
                </div>
              </div>

            </div>
          </div>
<?php 
        }
    } else{
        echo "0 results.";
    }
?>
        </div>
      </div>
    </div>


    <div class="site-section bg-primary py-5">
      <div class="container">
        <div class="row align-items-center">
          <div class="col-lg-7 mb-4 mb-md-0">
            <h2 class="mb-0 text-white">What are you waiting for?</h2>
            <p class="mb-0 opa-7">"Durian to drop? "</p>
          </div>
          <div class="col-lg-5 text-md-right">
            <a href="reservation.php" class="btn btn-primary btn-white">Book now</a>
          </div>
        </div>
      </div>
    </div>

      
<?php
    include('footer.php');
?>

    </div>

    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/jquery.sticky.js"></script>
    <script src="js/jquery.waypoints.min.js"></script>
    <script src="js/jquery.animateNumber.min.js"></script>
    <script src="js/jquery.fancybox.min.js"></script>
    <script src="js/jquery.easing.1.3.js"></script>
    <script src="js/bootstrap-datepicker.min.js"></script>
    <script src="js/aos.js"></script>

    <script src="js/main.js"></script>

  </body>

</html>

