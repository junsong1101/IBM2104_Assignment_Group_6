<?php
    if(!isset($_SESSION)){
           session_start();   
    }
?>
<!doctype html>
<html lang="en">
  <head>
    <title>Purchase History</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700;900&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="fonts/icomoon/style.css">

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.fancybox.min.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">
    <link rel="stylesheet" href="css/aos.css">

    <!-- MAIN CSS -->
    <link rel="stylesheet" href="css/style.css">
    <style>       
        .site-logo a{
            color: #000000;
            font-size: 1.7em;
        }
        .site-logo strong{
            font-weight: 900;
        }
        .ticket-container{
            width: 60%;
            margin: auto;
            font-family: sans-serif;
        }
        .title{
            text-align: center;
        }
        .ticket{
            border: 1px solid grey;
            padding: 10px 20px;
            background-color: #e4f2f2;
            margin-bottom: 40px;
        }
    </style>
  </head>
  <body>
    
    <div class="site-wrap" id="home-section">

      <div class="site-mobile-menu site-navbar-target">
        <div class="site-mobile-menu-header">
          <div class="site-mobile-menu-close mt-3">
            <span class="icon-close2 js-menu-toggle"></span>
          </div>
        </div>
        <div class="site-mobile-menu-body"></div>
      </div>

<?php
    include('header.php');
?>
  
        <div class="ticket-container" style="margin-top: 50px;">
            <h1 class="title">Purchase History</h1>
            
                <?php
                    include('database-config.php');
                    $user_id = $_SESSION['user_id'];
                
                    $sql = "SELECT * FROM tbl_reservation 
                            INNER JOIN tbl_trip 
                            ON tbl_reservation.trip_id = tbl_trip.trip_id 
                            INNER JOIN tbl_bus 
                            ON tbl_trip.bus_id = tbl_bus.bus_id 
                            WHERE user_id = '$user_id'
                            ORDER BY reserve_date DESC";
                    $result = mysqli_query($conn, $sql);
                    if(mysqli_num_rows($result) > 0){
                        while($row = mysqli_fetch_assoc($result)){
                ?>
            Date &amp; Time of Purchase: <?php echo $row['reserve_date']; ?>
            <div class="ticket">
                <div class="site-logo">
                    <a href="index.php"><strong>Xpress<a style="color:blue;">Bus</a></strong></a>
                </div><hr>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="row">
                                <div class="col-md-3">
                                    Ref No: <br>
                                    Bus No: <br>
                                </div>
                                <div class="col-md-3">
                                    <?php echo $row['reservation_id']; ?> <br>
                                    <?php echo $row['bus_id']; ?> <br>
                                </div>
                                <div class="col-md-3">
                                    Trip No: <br>
                                    User No: <br>
                                </div>
                                <div class="col-md-3">
                                    <?php echo $row['trip_id']; ?> <br>
                                    <?php echo $row['user_id']; ?> <br>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    Bus Name: <br>
                                    Bus Type: <br>
                                    Bus Plate Number: <br>
                                    Name: <br>
                                    Contact: <br>
                                    Email: <br>
                                    Payment Method: <br>
                                </div>
                                <div class="col-md-8">
                                    <?php echo $row['bus_name']; ?> <br>
                                    <?php echo $row['bus_type']; ?> <br>
                                    <?php echo $row['bus_number_plate']; ?> <br>
                                    <?php echo $row['reference_name']; ?> <br>
                                    <?php echo $row['contact_no']; ?> <br>
                                    <?php echo $row['reference_email']; ?> <br>
                                    <?php echo $row['payment_method']; ?> <br>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="row">
                                <div class="col-md-3">
                                    <b>Departure </b><br>
                                    Time: <br>
                                    Location: <br>
                                </div>
                                <div class="col-md-3">
                                    <br>
                                    <?php echo $row['departure_time']; ?> <br>
                                    <?php echo $row['departure_location']; ?> <br>
                                </div>
                                <div class="col-md-3">
                                    <b>Arrival </b><br>
                                    Time: <br>
                                    Location: <br>
                                </div>
                                <div class="col-md-3">
                                    <br>
                                    <?php echo $row['arrival_time']; ?> <br>
                                    <?php echo $row['arrival_location']; ?> <br>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    Trip Date: <br>
                                    Trip Fare /person: <br>
                                    Pax: <br>
                                    Total Fare: <br>
                                    Seat Number: <br>
                                </div>
                                <div class="col-md-8">
                                    <?php echo $row['trip_date']; ?> <br>
                                    <?php echo $row['trip_fare']; ?> <br>
                                    <?php $pax = $row['adult_pax']+$row['child_pax']; echo $pax; ?> <br>
                                    <?php $total = $pax*$row['trip_fare']; echo $pax; ?> <br>
                                    <?php echo $row['seats_reserved']; ?> <br>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
                <?php
                        }
                    }else{
                        echo "no results";
                    }
                ?>
                         
        </div>
        
<?php
    include('footer.php');
?>

    </div>

    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/jquery.sticky.js"></script>
    <script src="js/jquery.waypoints.min.js"></script>
    <script src="js/jquery.animateNumber.min.js"></script>
    <script src="js/jquery.fancybox.min.js"></script>
    <script src="js/jquery.easing.1.3.js"></script>
    <script src="js/bootstrap-datepicker.min.js"></script>
    <script src="js/aos.js"></script>
    <script src="//code.jquery.com/jquery-1.10.2.js"></script>
    <script src="js/main.js"></script>

  </body>

</html>