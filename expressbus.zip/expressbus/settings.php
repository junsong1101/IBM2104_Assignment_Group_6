<?php
    if(!isset($_SESSION)){
        session_start();
        include('check-login.php');
    }
    if ( isset($_GET['success']) && $_GET['success'] == 1 ) {
        include('alert.php');
         echo'<div class="alert">
          <span class="closebtn">&times;</span>  
          <strong>Fail!</strong> H/P Number need to be numbers!
        </div>';
    }
    if ( isset($_GET['success']) && $_GET['success'] == 2 ) {
        include('alert.php');
         echo'<div class="alert success">
          <span class="closebtn">&times;</span>  
          <strong>Success!</strong> Changes Saved
        </div>';
    }
    if ( isset($_GET['success']) && $_GET['success'] == 3 ) {
        include('alert.php');
         echo'<div class="alert">
          <span class="closebtn">&times;</span>  
          <strong>Fail!</strong> Error while saving! Please try again
        </div>';
    }

    if(isset($_POST['name']) && isset($_POST['phone']) && isset($_FILES['image']['name'])){
        
        include('database-config.php');
        $name = mysqli_real_escape_string($conn, $_POST['name']);
        $phone = mysqli_real_escape_string($conn, $_POST['phone']);
        $user_id = $_SESSION['user_id'];
        
        if(!is_numeric($phone) && strlen($phone) < 10 && strlen($phone) > 11){
            header("Location: settings.php?success=1");
            exit();
        }
        include('image-config.php');

        // Check extension
        if(in_array($imageFileType,$extensions_arr) ){

            include('image-encode.php');

            $sql = "UPDATE tbl_user SET 
            user_name = '$name',
            user_contact = '$phone',
            user_profile_image = '".$image."' 
            WHERE user_id = '$user_id'";

            if(mysqli_query($conn, $sql)){
                // Upload file
                move_uploaded_file($_FILES['image']['tmp_name'],$target_dir.$file);
                $conn->close();
                header("Location: settings.php?success=2");
                exit();
            }else{
                die('error' . mysqli_error($conn));
                $conn->close();
                header("Location: settings.php?success=3");
                exit();
            }
        }
        else{
            echo $_FILES['image']['name'];
        }
    }
?>
<!doctype html>
<html lang="en">

  <head>
    <title>Settings</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700;900&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="fonts/icomoon/style.css">

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.fancybox.min.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">
    <link rel="stylesheet" href="css/aos.css">

    <!-- MAIN CSS -->
    <link rel="stylesheet" href="css/style.css">
      <style>
          .submitbtn {
              background-color: #ffffff; 
              float: left;
              width: 100%;
              border: 2px solid #007bff;
              color: #007bff;
              margin: 8px 0;
              padding: 14px 20px;
          }
          .submitbtn:hover{
              background-color: #007bff;
              color: #ffffff;
          }.form-control{
              margin: 5px 0;
          }
          form{
              margin-top: 30px;
          }
      </style>
  </head>

  <body>

    
    <div class="site-wrap" id="home-section">

      <div class="site-mobile-menu site-navbar-target">
        <div class="site-mobile-menu-header">
          <div class="site-mobile-menu-close mt-3">
            <span class="icon-close2 js-menu-toggle"></span>
          </div>
        </div>
        <div class="site-mobile-menu-body"></div>
      </div>



<?php
        include('header.php');
?> 
        
        <h1 style="text-align: center;">Settings</h1>
    <section class="ftco-section">
    	<div class="container">
            <form action="settings.php" method="post" autocomplete="off" enctype="multipart/form-data">
                <div class="row">
                    <div class="col-lg-6 mb-5 ftco-animate">
                        <div class="imgcontainer">
                            <label for="profile-picture"><b>Add Profile Picture</b></label>
                          <img class="image" id="upload" src="images/defaultImg.png" style="width:100%;" >
                          <span id="spnFilePath"></span>
                          <input style="margin-top:20px;" type="file" onchange="readURL(this)" name="image" required>    
                        </div>
                    </div>
                    <div class="col-lg-6  pl-md-5 ftco-animate">
                            <div class="container" style="padding:16px;">
                              <label for="name"><b>User Name</b></label>
                              <input type="text" name="name" class="form-control" placeholder="Enter New User Name" required>

                              <label for="description"><b>Add H/P Number</b></label>
                              <input type="text" class="form-control" placeholder="Enter Phone Number" name="phone" required>
                                
                              <button type="submit" class="submitbtn">Save Changes</button>
                            </div>

                    </div>
                </div>
                </form>
    	</div>
    </section>
        
<?php
    include('footer.php');
?>

    </div>
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/jquery.sticky.js"></script>
    <script src="js/jquery.waypoints.min.js"></script>
    <script src="js/jquery.animateNumber.min.js"></script>
    <script src="js/jquery.fancybox.min.js"></script>
    <script src="js/jquery.easing.1.3.js"></script>
    <script src="js/bootstrap-datepicker.min.js"></script>
    <script src="js/aos.js"></script>
    <script src="js/main.js"></script>
    <script type="text/javascript">
    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $('#upload')
                    .attr('src', e.target.result)
            };

            reader.readAsDataURL(input.files[0]);
        }
    }
    </script>
  </body>
</html>