<?php
    if(!isset($_SESSION)){
        session_start();      
    }

    if(isset($_GET['id'])){
        $trip_id = $_GET['id'];
        include('database-config.php');
        $queries = "SELECT * FROM tbl_trip WHERE trip_id = '$trip_id'";
        $results = mysqli_query($conn, $queries);
        if(mysqli_num_rows($results) > 0){
            while($rowss = mysqli_fetch_assoc($results)){
                if($rowss['available_seats'] == 0){
                    mysqli_close($conn);
                    header("Location: reservation.php?success=4");
                    exit();
                }
            }
        }
    }
    if(isset($_POST['adult']) && isset($_POST['salutation']) && isset($_POST['name']) && isset($_POST['email']) && isset($_POST['phone']) && isset($_POST['payment-method']) && isset($_POST['seat'])){
        
        //assign submitted data to respective PHP variables
        $adult = $_POST['adult'];
        $child = $_POST['child'];
        $salutation = $_POST['salutation'];
        $name = $_POST['name'];
        $email = $_POST['email'];
        $phone = $_POST['phone'];
        $payment = $_POST['payment-method'];
        $checkbox = $_POST['seat'];
        $chk = "";
        foreach($checkbox as $chk1){
            $chk .= $chk1.",";
        }
        
        //validation starts here
        
        //adult pax should be at least 1
        if($adult < 1){
            mysqli_close($conn);
            header("Location: reservation.php?success=1");
            exit();
        }
        //phone must be numeric and correct length
        if(is_numeric($phone) && strlen($phone) > 9 && strlen($phone) < 12){
            //validated
        }else{
            mysqli_close($conn);
            header("Location: reservation.php?success=2");
            exit();
        }
        //num of checkbox checked must match num of pax
        if(count($checkbox) != ($adult+$child)){
            mysqli_close($conn);
            //need to deduct the available seats from database
            header("Location: reservation.php?success=3");
            exit();
        }
        
        $user_id = $_SESSION['user_id'];
        $trip_id = $_SESSION['trip_id'];
        
        include('database-config.php');       
        $sql="INSERT INTO tbl_reservation SET
                user_id = '$user_id',
                trip_id = '$trip_id',
                payment_method = '$payment',
                contact_no = '$phone',
                reference_name = '$name',
                reference_email = '$email',
                adult_pax = '$adult',
                child_pax = '$child',
                seats_reserved = '$chk',
                reserve_date = NOW()";
        if(mysqli_query($conn, $sql)){
            include('deduct-seats.php');
            $query = "SELECT * FROM tbl_reservation 
            WHERE user_id = '$user_id' AND 
            trip_id = '$trip_id' AND 
            reserve_date = (SELECT MAX(reserve_date) FROM tbl_reservation)";
            $res = mysqli_query($conn, $query);
            if(mysqli_query($conn, $query)){
                if (mysqli_num_rows($res) > 0){
                    while($rw = mysqli_fetch_assoc($res)){    
                        $reservation_id = $rw['reservation_id'];
                        header("Location: checkout.php?reserid=$reservation_id");
                        mysqli_close($conn);
                        exit();
                    }
                }
            }else{
                echo "cannot produce result";
            }
        }else{
            mysqli_close($conn);
            header("Location: reservation.php?success=5");
            exit();
        }
    }else{
?>
<!doctype html>
<html lang="en">
  <head>
    <title>Reservation Form</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700;900&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="fonts/icomoon/style.css">

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.fancybox.min.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">
    <link rel="stylesheet" href="css/aos.css">

    <!-- MAIN CSS -->
    <link rel="stylesheet" href="css/style.css">
    <style>
        h1{
            text-align: center;
        }
        .confirmbtn {
            background-color: #007bff; 
            float: left;
            width: 50%;
            border: none;
            color: white;
            margin-top: 50px;
            border: 2px solid;           
            border-color: #007bff;
            padding: 14px 20px;
        }
        .confirmbtn:hover{
            background-color: #ffffff;
            color: #007bff;
            font-weight: bold;
        }
        .list{
            border: 1px solid grey;
        }
        .list table {  
              width: 100%;
              table-layout: fixed;
              font-family: sans-serif;           
          }
          
          .list h1{
              font-family: cursive;
              font-size: 24pt;
          }
          
          .list th, td {
              text-align: left;
              overflow: hidden;
              box-sizing: border-box;
              text-align: center;
              font-size: 14pt;
              min-width: 30px;
          }
        .heading{
            background-color: #007bff;
            color: #ffffff;
        }
        .seats tbody tr td {
            border: 1px solid grey;
            border-radius: 5px;
        }
        .seats{
            border-collapse: separate;
            border-spacing: 30px;
        }
        .seats td{
            min-width: 30px;
            min-height: 30px;
            font-family: cursive;
        }
        .seats .cc{
            border: 0;
        }
        .seats td a.seat{
            cursor:  pointer;
        }
        .legend {
            padding-left: 0px;
            text-align: center;
            margin-bottom: 0px;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
        }
        .clearfix{
            zoom: 1;
            display: block;
            list-style-type: disc;
        }
        .legend li{
            display: inline-block;
            padding: 8px 20px;
            font-family: cursive;
            text-align: -webkit-match-parent;
            font-size: 18px;
        }
        .legend-available{
            background-color: #ffffff;
            border: 1px solid #ccc;
            float: left;
            height: 30px;
            width: 30px;
            border-radius: 3px;
            position: relative;
            overflow: hidden;
            margin-right:10px;
        }
        .legend-occupied{
            background-color: #ff5050;
            border: 1px solid #ff5050;
            float: left;
            height: 30px;
            width: 30px;
            border-radius: 3px;
            position: relative;
            overflow: hidden;
            margin-right:10px;
        }
        .legend-selected{
            background-color: #a9d86e;
            border: 1px solid #a9d86e;
            float: left;
            height: 30px;
            width: 30px;
            border-radius: 3px;
            position: relative;
            overflow: hidden;
            margin-right:10px;
        } 
        .seat-label {
            display: block;
            cursor: pointer;
            margin: 0;
        }
        .seat-cell{
            display: none;
        }
        .seat-cell:checked+.seat-label {
            background: #a9d86e;
            color: #ffffff;
        }
        .seat-cell:disabled+.seat-label {
            background: #ff5050;
            color: #ffffff;
            cursor: not-allowed;
        }
    </style>
  </head>

  <body>
    
    <div class="site-wrap" id="home-section">

      <div class="site-mobile-menu site-navbar-target">
        <div class="site-mobile-menu-header">
          <div class="site-mobile-menu-close mt-3">
            <span class="icon-close2 js-menu-toggle"></span>
          </div>
        </div>
        <div class="site-mobile-menu-body"></div>
      </div>

<?php
    include('header.php');
?>
        
        <form class="seats-form" action="seats.php" method="post" enctype="multipart/form-data">
            <div class="container" style="margin-top:100px; padding:20px;">
                <h1><b>Select Your Seats for Departing Trip: </b></h1>
                <div class="row" style="margin-top: 50px;">
                    <div class="col-md-8">
                        <ul class="legend clearfix">
                            <li><div class="legend-available"></div> Available </li>
                            <li><div class="legend-occupied"></div> Occupied </li>
                            <li><div class="legend-selected"></div> Selected </li>
                        </ul>
                        <div class="row" style="margin-top:50px;">
                            <div class="col-md-6">
                                <label for="adults"><b>Adult:</b></label>
                                <input type="number"class="form-control" name="adult" value="0" step="1" min="0" max="5" required>
                            </div>
                            <div class="col-md-6">
                                <label for="adults"><b>Child: *Below 6 years old</b></label>
                                <input type="number"class="form-control" name="child" value="0" step="1" min="0" max="5">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-4">
                                <label for="salutation"><b>Title: </b></label>
                                <select class="form-control" name="salutation" required>
                                    <option value="Mr."> Mr. </option>
                                    <option value="Mrs."> Mrs. </option>
                                    <option value="Ms."> Ms. </option>
                                </select>
                            </div>
                            <div class="col-md-8">
                                <label for="name"><b>Full Name: </b></label>
                                <input type="text" class="form-control" name="name" required>
                            </div>
                        </div>
                        <label for=""><b>Email Address: </b></label>
                        <input type="text" class="form-control" name="email" required>
                        <label for=""><b>H/P Number: </b></label>
                        <input type="text" class="form-control" name="phone" required>
                        <label for="payment-method"><b>Select Payment Method:</b></label>
                        <select class="form-control" name="payment-method" required>
                            <option value="cash"> Cash </option>
                            <option value="card"> Credit / Debit Card ( VISA / Master Card )</option>
                            <option value="online-banking"> Online Banking (FPS) </option>
                        </select>
                        <button type="submit" class="confirmbtn">Proceed to Checkout</button>
                            
                    </div>
                    <div class="col-md-4">
                        <div class="list">
                            <table>
                                <tr class="heading">
                                    <td style="width: 100%;">Front</td>
                                </tr>
                                <tbody>
                                    <tr>
                                        <td>
                                            <table class="seats">
                                                <tbody>
                                                    <?php
                                                    if(isset($_GET['id'])){
                                                        $trip_id = $_GET['id'];
                                                        $_SESSION['trip_id'] = $trip_id;
                                                        include('database-config.php');
                                                        $sql = "SELECT * FROM tbl_trip INNER JOIN tbl_bus ON tbl_trip.bus_id = tbl_bus.bus_id WHERE trip_id = '$trip_id' AND availability = 'y'";
                                                        $result = mysqli_query($conn, $sql);
                                                        if (mysqli_num_rows($result) > 0){
                                                            while($row = mysqli_fetch_assoc($result)){
                                                                $seats = $row['bus_seats']/3;
                                                                for($i=0; $i<$seats; $i++){
                                                    ?>
                                                                    <tr>                                                            
                                                    <?php
                                                                            for($j=0; $j<4; $j++){
                                                                                $col = " ";
                                                                                if($j==0){ $col = "A";}
                                                                                if($j==2){ $col = "B";}
                                                                                if($j==3){ $col = "C";}
                                                                                if($j==1){
                                                    ?>
                                                                        <td class="cc">
                                                                            <a class="seat">
                                                                                <div class="corridor-cell"></div>
                                                                            </a>
                                                                        </td>
                                                    <?php
                                                                                }else{
                                                    ?>
                                                                        <td>
                                                                            <a class="seat">
                                                                                <input type="checkbox" value="<?php echo ($i+1).$col; ?>" 
                                                                                class="seat-cell" id="seat<?php echo ($i+1).$col; ?>" name="seat[]" <?php
                                                                                    $seats_disable = "SELECT * FROM tbl_reservation WHERE trip_id = '$trip_id'";
                                                                                    $seat = ($i+1).$col;
                                                                                    $res = mysqli_query($conn, $seats_disable);
                                                                                    if (mysqli_num_rows($res) > 0){
                                                                                        while($rw = mysqli_fetch_assoc($res)){
                                                                                            $string = $rw['seats_reserved'];
                                                                                            $arr = explode(',', $string);
                                                                                            foreach($arr as $str){
                                                                                                if($str == $seat){
                                                                                                    echo 'disabled';
                                                                                                }
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                ?>>
                                                                                <label for="seat<?php echo ($i+1).$col; ?>" class="seat-label"><?php echo ($i+1).$col; ?></label>
                                                                            </a>
                                                                        </td>
                                                    <?php
                                                                                }
                                                                            }         
                                                    ?>
                                                                    </tr>
                                                    <?php
                                                                                
                                                                }
                                                            }
                                                        }
                                                    }
                                                    ?>
                                                    
                                                </tbody>       
                                            </table>
                                        </td>
                                    </tr>
                                </tbody>
                                <tr class="heading">
                                    <td style="width: 100%;">Back</td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </form>
        
        
        
<?php
    include('footer.php');
?>

    </div>

    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/jquery.sticky.js"></script>
    <script src="js/jquery.waypoints.min.js"></script>
    <script src="js/jquery.animateNumber.min.js"></script>
    <script src="js/jquery.fancybox.min.js"></script>
    <script src="js/jquery.easing.1.3.js"></script>
    <script src="js/bootstrap-datepicker.min.js"></script>
    <script src="js/aos.js"></script>
    <script src="//code.jquery.com/jquery-1.10.2.js"></script>
    <script src="js/main.js"></script>

  </body>

</html>
<?php } ?>
