<?php
    if(!isset($_SESSION)){
        session_start();
        include('check-login.php');
    }
?>
<!doctype html>
<html lang="en">

  <head>
    <title>Admin Page</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700;900&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="fonts/icomoon/style.css">

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.fancybox.min.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">
    <link rel="stylesheet" href="css/aos.css">

    <!-- MAIN CSS -->
    <link rel="stylesheet" href="css/style.css">
      <style>
          .navbtn {
              background-color: #ffffff; 
              float: left;
              width: 100%;
              border: 2px solid #007bff;
              color: #007bff;
              margin: 8px 0;
              padding: 14px 20px;
          }
          .navbtn:hover{
              background-color: #007bff;
              color: #ffffff;
          }
      </style>
  </head>

  <body>

    
    <div class="site-wrap" id="home-section">

      <div class="site-mobile-menu site-navbar-target">
        <div class="site-mobile-menu-header">
          <div class="site-mobile-menu-close mt-3">
            <span class="icon-close2 js-menu-toggle"></span>
          </div>
        </div>
        <div class="site-mobile-menu-body"></div>
      </div>



<?php
        include('header.php');
?>     
        
    <div class="site-section">
      <div class="container">
        <div class="row">
          <div class="col-lg-7">
            <h2 class="section-heading"><strong>Admin Control Panel</strong></h2>    
          </div>
        </div>

        <div class="row">
          <div class="col-lg-4 mb-5">
            <div class="service-1 dark">
              <span class="service-1-icon">
                <span class="icon-bus"></span>
              </span>
              <div class="service-1-contents">
                <h3>Bus Control Page</h3>
                <p>View, Add, Update &amp; Delete Buses</p>
                <button id="button1" class="navbtn">Enter</button>
              </div>
            </div>
          </div>
          <div class="col-lg-4 mb-5">
            <div class="service-1 dark">
              <span class="service-1-icon">
                <span class="icon-user"></span>
              </span>
              <div class="service-1-contents">
                <h3>User Control Page</h3>
                <p>View, Add, Update &amp; Delete Users</p>
                <button id="button2" class="navbtn">Enter</button>
              </div>
            </div>
          </div>
          <div class="col-lg-4 mb-5">
            <div class="service-1 dark">
              <span class="service-1-icon">
                <span class="icon-list"></span>
              </span>
              <div class="service-1-contents">
                <h3>Trip Control Page</h3>
                <p>View, Add, Update &amp; Delete Trips</p>
                <button id="button3" class="navbtn">Enter</button>
              </div>
            </div>
          </div>

          <div class="col-lg-4 mb-5">
            <div class="service-1 dark">
              <span class="service-1-icon">
                <span class="icon-calendar"></span>
              </span>
              <div class="service-1-contents">
                <h3>Reservation Control Page</h3>
                <p>View, Add, Update &amp; Delete Reservations</p>
                <button id="button4" class="navbtn">Enter</button>
              </div>
            </div>
          </div>
          <div class="col-lg-4 mb-5">
            <div class="service-1 dark">
              <span class="service-1-icon">
                <span class="icon-compass"></span>
              </span>
              <div class="service-1-contents">
                <h3>Location Control Page</h3>
                <p>View, Add, Update &amp; Delete Locations</p>
                <button id="button5" class="navbtn">Enter</button>
              </div>
            </div>
          </div>
          <div class="col-lg-4 mb-5">
            <div class="service-1 dark">
              <span class="service-1-icon">
                <span class="icon-envelope"></span>
              </span>
              <div class="service-1-contents">
                <h3>Message Control Page</h3>
                <p>View, Add, Update &amp; Delete Messages</p>
                <button id="button6" class="navbtn">Enter</button>
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>
        
<?php
    include('footer.php');
?>

    </div>

    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/jquery.sticky.js"></script>
    <script src="js/jquery.waypoints.min.js"></script>
    <script src="js/jquery.animateNumber.min.js"></script>
    <script src="js/jquery.fancybox.min.js"></script>
    <script src="js/jquery.easing.1.3.js"></script>
    <script src="js/bootstrap-datepicker.min.js"></script>
    <script src="js/aos.js"></script>
    <script src="js/main.js"></script>
    <script type="text/javascript">
        document.getElementById("button1").onclick = function () {
            location.href = "bus-control.php";
        };
        document.getElementById("button2").onclick = function () {
            location.href = "user-control.php";
        };
        document.getElementById("button3").onclick = function () {
            location.href = "trip-control.php";
        };
        document.getElementById("button4").onclick = function () {
            location.href = "res-control.php";
        };
        document.getElementById("button5").onclick = function () {
            location.href = "loc-control.php";
        };
        document.getElementById("button6").onclick = function () {
            location.href = "mes-control.php";
        };
        
    </script>
  </body>

</html>