<?php
    if(!isset($_SESSION)){
        session_start();
        include('check-login.php');
    }

    if(isset($_POST['name']) && isset($_POST['status'])){
        
        include('database-config.php');
        $name = mysqli_real_escape_string($conn, $_POST['name']);
        $status = mysqli_real_escape_string($conn, $_POST['status']);
        $id = $_GET['id'];

        $sql = "UPDATE tbl_area_location SET 
        area_name = '$name',
        status = '$status' 
        WHERE area_id = '$id'";

        if(mysqli_query($conn, $sql)){
            $conn->close();
            header("Location: loc-control.php?success=1");
            exit();
        }else{
            die('error' . mysqli_error($conn));
            $conn->close();
            header("Location: loc-control.php?success=2");
            exit();
        }
    }
?>
<!doctype html>
<html lang="en">

  <head>
    <title>Admin &mdash; Update Location</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700;900&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="fonts/icomoon/style.css">

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.fancybox.min.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">
    <link rel="stylesheet" href="css/aos.css">

    <!-- MAIN CSS -->
    <link rel="stylesheet" href="css/style.css">
      <style>
          .submitbtn {
              background-color: #ffffff; 
              float: left;
              width: 100%;
              border: 2px solid #007bff;
              color: #007bff;
              margin: 8px 0;
              padding: 14px 20px;
          }
          .submitbtn:hover{
              background-color: #007bff;
              color: #ffffff;
          }.form-control{
              margin: 5px 0;
          }
          form{
              width: 50%;
              margin: auto;
          }
      </style>
  </head>

  <body>

    
    <div class="site-wrap" id="home-section">

      <div class="site-mobile-menu site-navbar-target">
        <div class="site-mobile-menu-header">
          <div class="site-mobile-menu-close mt-3">
            <span class="icon-close2 js-menu-toggle"></span>
          </div>
        </div>
        <div class="site-mobile-menu-body"></div>
      </div>



<?php
        include('header.php');
?> 
<?php 
    $id = $_GET['id'];
    include('database-config.php');

    $sql = "SELECt * FROM tbl_area_location WHERE area_id = $id";
    $result = mysqli_query($conn, $sql);

    if ($result->num_rows > 0) {
        while($row = mysqli_fetch_assoc($result)) {
?>        
        <h1 style="text-align: center;">Update Location Details</h1>
    <section class="ftco-section">
    	<div class="container">
            <form action="edit-loc.php?id=<?php echo $row['area_id']; ?>" method="post" autocomplete="off" enctype="multipart/form-data">
                <div class="container" style="padding:16px;">
                  <label for="name"><b>Name</b></label>
                  <input type="text" name="name" class="form-control" placeholder="<?php echo $row['area_name']; ?>" required>

                  <label for="status"><b>Status</b></label>
                  <select name="status" class="form-control" required>
                      <option value="1">Enabled</option>
                      <option value="0">Disabled</option>
                  </select>

                  <button type="submit" class="submitbtn">Update Location</button>
                </div>
            </form>
    	</div>
    </section>
<?php
        }
    }else {
      echo "0 results";
    }
    $conn->close();           
?>        
<?php
    include('footer.php');
?>

    </div>
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/jquery.sticky.js"></script>
    <script src="js/jquery.waypoints.min.js"></script>
    <script src="js/jquery.animateNumber.min.js"></script>
    <script src="js/jquery.fancybox.min.js"></script>
    <script src="js/jquery.easing.1.3.js"></script>
    <script src="js/bootstrap-datepicker.min.js"></script>
    <script src="js/aos.js"></script>
    <script src="js/main.js"></script>
    <script type="text/javascript">
    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $('#upload')
                    .attr('src', e.target.result)
            };

            reader.readAsDataURL(input.files[0]);
        }
    }
    </script>
  </body>
</html>