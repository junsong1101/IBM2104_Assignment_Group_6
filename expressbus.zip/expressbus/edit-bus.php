<?php
    if(!isset($_SESSION)){
        session_start();
        include('check-login.php');
    }

    if(isset($_POST['name']) && isset($_POST['description']) && isset($_POST['type']) && isset($_POST['seats']) && isset($_POST['ac']) && isset($_POST['numberplate']) && isset($_FILES['image']['name'])){
        
        include('database-config.php');
        $name = mysqli_real_escape_string($conn, $_POST['name']);
        $type = mysqli_real_escape_string($conn, $_POST['type']);
        $description = mysqli_real_escape_string($conn, $_POST['description']);
        $seats = mysqli_real_escape_string($conn, $_POST['seats']);
        $ac = mysqli_real_escape_string($conn, strtolower($_POST['ac']));
        $numberplate = mysqli_real_escape_string($conn, $_POST['numberplate']);
        $id = $_GET['id'];
        
        if(!is_numeric($seats)){
            header("Location: edit-bus.php?success=1");
            exit();
        }
        include('image-config.php');

        // Check extension
        if(in_array($imageFileType,$extensions_arr) ){

            include('image-encode.php');

            $sql = "UPDATE tbl_bus SET 
            bus_name = '$name',
            bus_type = '$type',
            bus_description = '$description',
            bus_seats = '$seats',
            bus_number_plate = '$numberplate',
            bus_ac = '$ac',
            bus_image = '".$image."' 
            WHERE bus_id = '$id'";

            if(mysqli_query($conn, $sql)){
                // Upload file
                move_uploaded_file($_FILES['image']['tmp_name'],$target_dir.$file);
                $conn->close();
                header("Location: bus-control.php?success=1");
                exit();
            }else{
                die('error' . mysqli_error($conn));
                $conn->close();
                header("Location: bus-control.php?success=2");
                exit();
            }
        }
        else{
            echo $_FILES['image']['name'];
        }
    }
?>
<!doctype html>
<html lang="en">

  <head>
    <title>Admin &mdash; Update Bus</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700;900&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="fonts/icomoon/style.css">

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.fancybox.min.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">
    <link rel="stylesheet" href="css/aos.css">

    <!-- MAIN CSS -->
    <link rel="stylesheet" href="css/style.css">
      <style>
          .submitbtn {
              background-color: #ffffff; 
              float: left;
              width: 100%;
              border: 2px solid #007bff;
              color: #007bff;
              margin: 8px 0;
              padding: 14px 20px;
          }
          .submitbtn:hover{
              background-color: #007bff;
              color: #ffffff;
          }.form-control{
              margin: 5px 0;
          }
      </style>
  </head>

  <body>

    
    <div class="site-wrap" id="home-section">

      <div class="site-mobile-menu site-navbar-target">
        <div class="site-mobile-menu-header">
          <div class="site-mobile-menu-close mt-3">
            <span class="icon-close2 js-menu-toggle"></span>
          </div>
        </div>
        <div class="site-mobile-menu-body"></div>
      </div>



<?php
        include('header.php');
?> 
<?php 
    $id = $_GET['id'];
    include('database-config.php');

    $sql = "SELECt * FROM tbl_bus WHERE bus_id = $id";
    $result = mysqli_query($conn, $sql);

    if ($result->num_rows > 0) {
        while($row = mysqli_fetch_assoc($result)) {
?>        
        <h1 style="text-align: center;">Update Bus Details</h1>
    <section class="ftco-section">
    	<div class="container">
            <form action="edit-bus.php?id=<?php echo $row['bus_id']; ?>" method="post" autocomplete="off" enctype="multipart/form-data">
                <div class="row">
                    <div class="col-lg-6 mb-5 ftco-animate">
                        <div class="imgcontainer">
                          <img class="image" id="upload" src="images/defaultImg.png" style="width:100%;" >
                          <span id="spnFilePath"></span>
                          <input style="margin-top:20px;" type="file" onchange="readURL(this)" name="image" required>    
                        </div>
                    </div>
                    <div class="col-lg-6  pl-md-5 ftco-animate">
                            <div class="container" style="padding:16px;">
                              <label for="name"><b>Name</b></label>
                              <input type="text" name="name" class="form-control" placeholder="<?php echo $row['bus_name']; ?>" required>

                              <label for="name"><b>Type</b></label>
                              <select name="type" class="form-control" required>
                                  <option value="Single Decker">Single Decker</option>
                                  <option value="Double Decker">Double Decker</option>
                              </select>

                              <label for="description"><b>Description</b></label>
                              <input type="text" class="form-control" placeholder="<?php echo $row['bus_description']; ?>" name="description" required>

                              <label for="quantity"><b>Seats</b></label>
                              <input type="text"  class="form-control" placeholder="<?php echo $row['bus_seats']; ?>"  name="seats" required>

                              <label for="price"><b>Have AC (y = yes/ n = no)</b></label>
                              <select name="ac" class="form-control" required>
                                  <option value="y">Yes</option>
                                  <option value="n">No</option>
                              </select>

                              <label for="shippingfee"><b>Number Plate</b></label>
                              <input type="text" name="numberplate" class="form-control" placeholder="<?php echo $row['bus_number_plate']; ?>" required>
                                
                              <button type="submit" class="submitbtn">Update Bus Details</button>
                            </div>

                    </div>
                </div>
                </form>
    	</div>
    </section>
<?php
        }
    }else {
      echo "0 results";
    }
    $conn->close();           
?>        
<?php
    include('footer.php');
?>

    </div>
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/jquery.sticky.js"></script>
    <script src="js/jquery.waypoints.min.js"></script>
    <script src="js/jquery.animateNumber.min.js"></script>
    <script src="js/jquery.fancybox.min.js"></script>
    <script src="js/jquery.easing.1.3.js"></script>
    <script src="js/bootstrap-datepicker.min.js"></script>
    <script src="js/aos.js"></script>
    <script src="js/main.js"></script>
    <script type="text/javascript">
    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $('#upload')
                    .attr('src', e.target.result)
            };

            reader.readAsDataURL(input.files[0]);
        }
    }
    </script>
  </body>
</html>