<?php
    if(!isset($_SESSION)){
        session_start();
        include('check-login.php');
    }

    //notification banners section
    if ( isset($_GET['success']) && $_GET['success'] == 1 ) {
        include('alert.php');
         echo'<div class="alert">
          <span class="closebtn">&times;</span>  
          <strong>Fail!</strong> Adult pax should at least be 1 or more!
        </div>';
    }
    if ( isset($_GET['success']) && $_GET['success'] == 2 ) {
        include('alert.php');
         echo'<div class="alert">
          <span class="closebtn">&times;</span>  
          <strong>Fail!</strong> H/P Number must contain only 10 - 11 digits.
        </div>';
    }
    if ( isset($_GET['success']) && $_GET['success'] == 3 ) {
        include('alert.php');
         echo'<div class="alert">
          <span class="closebtn">&times;</span>  
          <strong>Fail!</strong> Seat Selected does not match the number of pax entered!
        </div>';
    }
    if ( isset($_GET['success']) && $_GET['success'] == 4 ) {
        include('alert.php');
         echo'<div class="alert">
          <span class="closebtn">&times;</span>  
          <strong>Fail!</strong> Sorry, all available seats for this trip are reserved. Please choose another trip!
        </div>';
    }
    if ( isset($_GET['success']) && $_GET['success'] == 5 ) {
        include('alert.php');
         echo'<div class="alert success">
          <span class="closebtn">&times;</span>  
          <strong>Fail!</strong> Error found! Please try again later.
        </div>';
    }
    //notification banners section end
?>
<!doctype html>
<html lang="en">

  <head>
    <title>Ticket Reservation</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" href="fonts/icomoon/style.css">

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.fancybox.min.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">
    <link rel="stylesheet" href="css/aos.css">

    <!-- MAIN CSS -->
    <link rel="stylesheet" href="css/style.css">
      <style>
          .list table {
              width: 70%;
              margin: 20px auto;
              table-layout: fixed;
              font-family: sans-serif;      
          }
          
          .list h1{
              font-family: cursive;
              font-size: 24pt;
          }
          
          .list th, td {
              border: none;
              border-collapse: collapse;
              text-align: left;
              overflow: hidden;
              box-sizing: border-box;
              text-align: center;
              font-size: 14pt;
          }
          
          .list td{
              height: 170px;
          }
          
          .list img{
              width: 100%;
              height: auto;
              vertical-align: middle;
              
          }
          .list .column1{
              position:inherit;
          }
          .modal{
              display: none;
              position: fixed;
              z-index: 1;
              left: 0;
              top: 0;
              overflow: auto;
              width: 100%;
              height: 100%;
              padding-top: 60px;
              background-color: rgb(0,0,0); /* Fallback color */
              background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
          }
          button:hover {
              opacity: 0.8;
          }
          
          .modal-content {
              background-color: :#fefefe;
              margin: 5% auto 15% auto;
              border: 1px solid #888;
              width: 70%;
          }
          .cancelbtn {
              width: auto;
              padding: 10px 18px;
              background-color: #f44336;
            }
          
          .close {
              position: absolute;
              right: 400px;
              top: 100px;
              color: #ffffff;
              font-size: 35px;
              font-weight: bold;
            }
          .close:hover,
          .close:focus {
              color: red;
              cursor: pointer;
            }
          .animate {
              -webkit-animation: animatezoom 0.6s;
              animation: animatezoom 0.6s
            }

            @-webkit-keyframes animatezoom {
              from {-webkit-transform: scale(0)} 
              to {-webkit-transform: scale(1)}
            }

            @keyframes animatezoom {
              from {transform: scale(0)} 
              to {transform: scale(1)}
            }

            /* Change styles for span and cancel button on extra small screens */
            @media screen and (max-width: 300px) {
              .cancelbtn {
                 width: 100%;
              }
          }
          .seats{
              cursor: pointer;
          }
          .blue{
              color: blue;
          }
          .dd{
              padding: 5px;
          }
      </style>
  </head>

  <body>

    
    <div class="site-wrap" id="home-section">

      <div class="site-mobile-menu site-navbar-target">
        <div class="site-mobile-menu-header">
          <div class="site-mobile-menu-close mt-3">
            <span class="icon-close2 js-menu-toggle"></span>
          </div>
        </div>
        <div class="site-mobile-menu-body"></div>
      </div>

<?php
    include('header.php');
        
    if(!isset($_POST['from']) && !isset($_POST['to']) && !isset($_POST['onward'])){
?>
      
      <div class="hero" style="background-image: url('images/bus-bg.jpg');">
        
        <div class="container">
          <div class="row align-items-center justify-content-center">
            <div class="col-lg-10">
              
              <form action="reservation.php" method="post" autocomplete="off" enctype="multipart/form-data" class="trip-form">
                
                <div class="row align-items-center">
                  <div class="mb-3 mb-md-0 col-md-6">
                      <div class="row">
                          <div class="mb-3 mb-md-0 col-md-6">
                            <label for="departure"><b>From: </b></label>
                            <select name="from" class="form-control" required>
                            <?php
                                include('database-config.php');
                                $sql = "SELECT * FROM tbl_area_location WHERE status = '1'";
                                $result = mysqli_query($conn, $sql);
                                if(mysqli_num_rows($result) > 0){
                                    while($row = mysqli_fetch_assoc($result)){
                            ?>
                                        <option class="dd" value="<?php echo $row['area_name']?>"><?php echo $row['area_name']?></option>
                            <?php
                                    }
                                }
                                mysqli_close($conn);
                            ?>        
                            </select>
                          </div>
                          <div class="mb-3 mb-md-0 col-md-6">
                            <label for="arrival"><b>To: </b></label>
                            <select name="to" class="form-control" required>
                            <?php
                                include('database-config.php');
                                $sql = "SELECT * FROM tbl_area_location WHERE status = '1' ORDER BY area_id DESC";
                                $result = mysqli_query($conn, $sql);
                                if(mysqli_num_rows($result) > 0){
                                    while($row = mysqli_fetch_assoc($result)){
                            ?>
                                        <option value="<?php echo $row['area_name']?>"><?php echo $row['area_name']?></option>
                            <?php
                                    }
                                }
                                mysqli_close($conn);
                            ?>  
                            </select>
                          </div>
                      </div>
                    </div>
                    <div class="mb-3 mb-md-0 col-md-6">
                      <div class="row">
                          <div class="mb-3 mb-md-0 col-md-6">
                            <div class="form-control-wrap">
                              <label for="departure"><b>Departure: </b></label>
                              <input type="text" name="onward" id="cf-3" placeholder="Date" class="form-control datepicker px-3" required>
                              <span class="icon icon-date_range"></span>

                            </div>
                          </div>
                          <div class="mb-3 mb-md-0 col-md-6">
                            <label for=""><b></b></label>
                        <input type="submit" value="Search" class="btn btn-primary btn-block py-3">
                          </div>
                      </div>
                    </div>
                </div>           
                </form>
            </div>
          </div>
        </div>
      </div>
<?php
    }
    if(isset($_POST['from']) && isset($_POST['to']) && isset($_POST['onward'])){
        
        include('database-config.php');
        
        //escape special characters
        $departure_location = mysqli_real_escape_string($conn, $_POST['from']);
        $arrival_location = mysqli_real_escape_string($conn, $_POST['to']);
        $trip_date = mysqli_real_escape_string($conn, $_POST['onward']);
        
        if($departure_location == $arrival_location){
            header('Location: index.php?success=');
            exit();
        }
        
        $sql = "SELECT * FROM tbl_trip INNER JOIN tbl_bus ON tbl_trip.bus_id = tbl_bus.bus_id WHERE
        departure_location = '$departure_location'AND
        arrival_location = '$arrival_location'AND
        trip_date = '$trip_date'AND
        availability = 'y'"; 
        $result = mysqli_query($conn, $sql);
?>        
        
    <div class="list" style="overflow-x:auto; margin-top: 50px;">
        <h1 style="text-align: center;">Your Choice of Journey: </h1>
        <table>
            <tr class="blue">
              <th class="column1"><?php echo mysqli_num_rows($result)?> Buses found </th>
              <th class="column2">Bus Company</th>
              <th class="column3">Departure</th>
              <th class="column4">Arrival</th>
              <th class="column5">Seats Available</th>
              <th class="column6">Bus Fare</th>
              <th class="column7">View Seats</th>
            </tr>
            <hr>
<?php
        if (mysqli_num_rows($result) > 0) {
            while($row = mysqli_fetch_assoc($result)) {
?>
            <tr>
              <th class="column1"><img src="<?php 
                        if($row['bus_image'] != null){
                            echo $row['bus_image'];
                        }else{
                            ?>images/defaultImg.png<?php
                        } ?>"></th>
              <th class="column2"><?php echo $row['bus_name']; ?></th>
              <th class="column3"><?php echo $row['departure_time']; ?><br> <?php echo $row['departure_location']; ?></th>
              <th class="column4"><?php echo $row['arrival_time']; ?><br> <?php echo $row['arrival_location']; ?></th>
              <th class="column5"><?php echo $row['bus_seats']; ?></th>
              <th class="column6">RM <?php 
                                        $fare = $row['trip_fare'];
                                        $lPrice = round($fare, 2);
                                        echo number_format((float)$lPrice, 2, '.', '');
                                     ?></th>
                <th class="column7">
                    <button id="myButton<?php echo $row['trip_id']; ?>" class="btn btn-primary btn-block py-3" >View Seats</button>
                </th>
            </tr>
            <script type="text/javascript">
                document.getElementById("myButton<?php echo $row['trip_id']; ?>").onclick = function () {
                    location.href = "seats.php?id=<?php echo $row['trip_id']; ?>";
                };
            </script>
<?php 
            }
        }else{
?>
            <tr>
                <div style="text-align: center;">
                    <a>No results</a>
                </div>
            </tr>
            
<?php
        }
?>           
        </table>
        <hr>
    </div>        
        
<?php
        }
    include('footer.php');
?>

    </div>

    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/jquery.sticky.js"></script>
    <script src="js/jquery.waypoints.min.js"></script>
    <script src="js/jquery.animateNumber.min.js"></script>
    <script src="js/jquery.fancybox.min.js"></script>
    <script src="js/jquery.easing.1.3.js"></script>
    <script src="js/bootstrap-datepicker.min.js"></script>
    <script src="js/aos.js"></script>
    <script src="js/scripts.js"></script>
    <script src="js/main.js"></script>
  </body>

</html>