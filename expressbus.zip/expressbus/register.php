<?php
    if(isset($_POST['email']) && isset($_POST['password']) && isset($_POST['username'])){
        
        //database configuration
        include("database-config.php");

        //escape special characters
        $username = mysqli_real_escape_string($conn, $_POST['username']);
        $email = mysqli_real_escape_string($conn, $_POST['email']);
        $password = mysqli_real_escape_string($conn, $_POST['password']);
        $type = mysqli_real_escape_string($conn, "customer");
        $hash = password_hash($password, PASSWORD_DEFAULT);
            
        //verify password is same with hash
        if (password_verify($password, $hash)) {
            //SQL code for insert data
            $sql = "INSERT INTO tbl_user (user_name, user_type, user_email, user_password) 
            VALUES ('$username','$type','$email','$hash')";
            
            if(mysqli_query($conn, $sql)){              
                //close database
                $conn->close();
                header("Location: login.php?success=3");
                exit();
                
            }else{             
                //error
                die('error' . mysqli_error($conn));
                $conn->close();
                header("Location: login.php?success=2");
                exit();
            }
            
        }else{
            //hashing error
            $conn->close();
            header("Location: login.php?success=5");
            exit();
        }
    }else{
        //form not submitted
?>
<!doctype html>
<html lang="en">

  <head>
    <title>Register Account</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700;900&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="fonts/icomoon/style.css">

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.fancybox.min.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">
    <link rel="stylesheet" href="css/aos.css">

    <!-- MAIN CSS -->
    <link rel="stylesheet" href="css/style.css">
      <style>
        .signupbtn {
              background-color: #007bff; 
              float: left;
              width: 100%;
              border: none;
              color: white;
              margin: 8px 0;
              padding: 14px 20px;
          }
          .image{
              opacity: 1;
              display: block;
              width: 100%;
              height: auto;
              transition:  .5 ease;
              backface-visibility: hidden;
              cursor: pointer;
          }
    </style>
  </head>

  <body>

    
    <div class="site-wrap" id="home-section">

      <div class="site-mobile-menu site-navbar-target">
        <div class="site-mobile-menu-header">
          <div class="site-mobile-menu-close mt-3">
            <span class="icon-close2 js-menu-toggle"></span>
          </div>
        </div>
        <div class="site-mobile-menu-body"></div>
      </div>

<?php
    include('header.php');
?>
        
        <section class="ftco-section" style="margin-top: 50px;">
    	<div class="container">
            <form action="register.php" method="post"  enctype="multipart/form-data">
                <div class="row">
                    <div class="col-lg-6 mb-5 ftco-animate">
                        <div class="imgcontainer">
                          <img class="image" id="upload" src="images/register.jpg">  
                        </div>
                    </div>
                    <div class="col-lg-6  pl-md-5 ftco-animate">
                        <div class="container" style="padding:16px;">
                            <h1 style="margin-bottom: 50px;">Register</h1>
                            <label for="email"><b>Email</b></label>
                            <input type="email" name="email" class="form-control" placeholder="Enter Email Address" required>

                            <label for="uname"><b>Username</b></label>
                            <input type="text" class="form-control" placeholder="Enter Username" name="username" required>

                            <label for="psw"><b>Password</b></label>
                            <input type="password"  class="form-control" placeholder="Enter Password" id="password" name="password" required>

                            <label for="psw-repeat"><b>Confirm Password</b></label>
                            <input type="password" class="form-control" id="confirm_password" placeholder="Confirm Password" name="psw-repeat" required>

                            <p>By creating an account you agree to our <a href="#" style="color:dodgerblue">Terms &amp; Privacy</a>.</p>

                            <div class="clearfix">
                                <button type="submit" class="signupbtn" onclick="return Validate()">Sign Up</button>
                            </div>
                            <div class="container">
                              <span class="psw">Already have account? <a href="login.php">Login Now!</a></span>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
    	</div>
    </section>
        
<?php
    include('footer.php');
?>

    </div>

    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/jquery.sticky.js"></script>
    <script src="js/jquery.waypoints.min.js"></script>
    <script src="js/jquery.animateNumber.min.js"></script>
    <script src="js/jquery.fancybox.min.js"></script>
    <script src="js/jquery.easing.1.3.js"></script>
    <script src="js/bootstrap-datepicker.min.js"></script>
    <script src="js/aos.js"></script>
<script type="text/javascript">
            var password = document.getElementById("password")
              , confirm_password = document.getElementById("confirm_password");

            function validatePassword(){
              if(password.value != confirm_password.value) {
                confirm_password.setCustomValidity("Passwords Don't Match");
              } else {
                confirm_password.setCustomValidity('');
              }
            }

            password.onchange = validatePassword;
            confirm_password.onkeyup = validatePassword;
        </script>
    <script src="js/main.js"></script>

  </body>

</html>
<?php } ?>