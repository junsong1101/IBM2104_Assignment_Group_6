<?php
     if(isset($_GET['id'])){
         $id = $_GET['id'];
         include('database-config.php');

         $sql = "DELETE FROM tbl_bus WHERE bus_id = $id";

         if(mysqli_query($conn, $sql)){
             $conn->close();
             header("Location: bus-control.php?success=1");
             exit();
         }else{
             die('error' . mysqli_error($conn));
             $conn->close();
             header("Location: bus-control.php?success=2");
             exit();
         }
      }
?>