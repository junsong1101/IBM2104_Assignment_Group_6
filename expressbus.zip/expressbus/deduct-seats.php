<?php
include('database-config.php');
$string = $chk;
$arr = explode(',', $string);
$count = count($arr)-1;

$sssql = "UPDATE tbl_trip SET available_seats = available_seats - '$count' WHERE available_seats > 0";
$ssssql = "UPDATE tbl_trip SET availability = 'n' WHERE available_seats = 0";
mysqli_query($conn, $sssql);
if(mysqli_query($conn, $ssssql)){

}
?>