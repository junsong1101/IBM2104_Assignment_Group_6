<?php
    session_start();
    if(isset($_SESSION['user_name'])){
        unset($_SESSION['user_name']);
        unset($_SESSION['user_type']);
        unset($_SESSION['user_email']);
        unset($_SESSION['user_id']);
        unset($_SESSION['user_contact']);
        session_destroy();
        header("Location: login.php?success=2");
    }
?>