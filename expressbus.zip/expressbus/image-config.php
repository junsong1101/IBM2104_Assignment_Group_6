<?php
    //config
    $file = $_FILES['image']['name'];
    $target_dir = "upload/";
    $target_file = $target_dir . basename($_FILES['image']['name']);          

    // Select file type
    $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

    // Valid file extensions
    $extensions_arr = array("jpg","jpeg","png","gif");
?>