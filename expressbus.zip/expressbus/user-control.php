<?php
    if(!isset($_SESSION)){
        session_start();
        include('check-login.php');
    }
    if ( isset($_GET['success']) && $_GET['success'] == 1 ) {
        include('alert.php');
         echo'<div class="alert success">
          <span class="closebtn">&times;</span>  
          <strong>Success!</strong> Changes Saved
        </div>';
    }
    if ( isset($_GET['success']) && $_GET['success'] == 2 ) {
        include('alert.php');
         echo'<div class="alert">
          <span class="closebtn">&times;</span>  
          <strong>Fail!</strong> Error No changes made.
        </div>';
    }
?>
<!doctype html>
<html lang="en">

  <head>
    <title>Admin &mdash; User Control</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700;900&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="fonts/icomoon/style.css">

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.fancybox.min.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">
    <link rel="stylesheet" href="css/aos.css">

    <!-- MAIN CSS -->
    <link rel="stylesheet" href="css/style.css">
      <style>
          .submitbtn {
              background-color: #ffffff; 
              float: left;
              width: 100%;
              border: 2px solid #007bff;
              color: #007bff;
              margin: 8px 0;
              padding: 14px 20px;
          }
          .submitbtn:hover{
              background-color: #007bff;
              color: #ffffff;
          }
          .addbtn {
              background-color: #82ae46; 
              float: left;
              width: 100%;
              border: none;
              color: white;
              margin: 8px 0;
              padding: 14px 20px;
          }
          h1{
              text-align: center;
          }
          
          table {
              width: 70%;
              margin: 20px auto;
              table-layout: fixed;
          }
          
          th, td {
              border: solid 1px;
              border-collapse: collapse;
              text-align: left;
              overflow: hidden;
              box-sizing: border-box;
              text-align: center;
          }
          
          td{
              height: 120px;
          }
          
          img{
              width: 100%;
              height: 100%;
              vertical-align: middle;
              
          }
          .column1{
              position:inherit;
          }
        tr:nth-child(even) {background-color: #f2f2f2;}
      </style>
  </head>

  <body>

    
    <div class="site-wrap" id="home-section">

      <div class="site-mobile-menu site-navbar-target">
        <div class="site-mobile-menu-header">
          <div class="site-mobile-menu-close mt-3">
            <span class="icon-close2 js-menu-toggle"></span>
          </div>
        </div>
        <div class="site-mobile-menu-body"></div>
      </div>



<?php
        include('header.php');
?>   
        
        <div style="overflow-x:auto;">
          <h1>User Control Panel</h1>
          <table>
            <tr>
              <th class="column1">Image</th>
              <th class="column2">Name</th>
              <th class="column3">Type</th>
              <th class="column4">Email</th>
              <th class="column5">H/P Number</th>
              <th class="column6">Action</th>
              <th class="column7">Action</th>
            </tr>
            <tr>
              <th class="column1"></th>
              <th class="column2"></th>
              <th class="column3"></th>
              <th class="column4"></th>
              <th class="column5"></th>
              <th class="column6"></th>
              <th class="column7"><a href="add-user.php" class="">Add User</a></th>
            </tr>
<?php
    include('database-config.php');

    $sql = "SELECT * FROM tbl_user ORDER BY user_id DESC";
    $result = mysqli_query($conn, $sql);

    if ($result->num_rows > 0) {
        while($row = mysqli_fetch_assoc($result)) {
?>
            <tr>
              <td class="column1"><img src="<?php 
                                                if($row['user_profile_image'] == NULL){
                                                    echo "images/defaultImg.png";
                                                }else{
                                                    echo $row['user_profile_image']; 
                                                }                       
                                            ?>"></td>
              <td class="column2"><?php echo $row['user_name']; ?></td>
              <td class="column3"><?php echo $row['user_type']; ?></td>
              <td class="column4"><?php echo $row['user_email']; ?></td>
              <td class="column5"><?php echo $row['user_contact']; ?></td>
              <td class="column6"><a href="edit-user.php?id=<?php echo $row['user_id']; ?>">Edit</a></td>
              <td class="column7"><a href="delete-user.php?id=<?php echo $row['user_id']; ?>" onclick="return confirmDelete(this);">Delete</a></td>
            </tr>
<?php
        }
    }else {
      echo "0 results";
    }
    $conn->close();           
?>
              
      </table>
      </div>
        
<?php
    include('footer.php');
?>

    </div>

    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/jquery.sticky.js"></script>
    <script src="js/jquery.waypoints.min.js"></script>
    <script src="js/jquery.animateNumber.min.js"></script>
    <script src="js/jquery.fancybox.min.js"></script>
    <script src="js/jquery.easing.1.3.js"></script>
    <script src="js/bootstrap-datepicker.min.js"></script>
    <script src="js/aos.js"></script>
    <script src="js/main.js"></script>
    <script>
    function confirmDelete(link) {
        if (confirm("Are you sure?")) {
            doAjax(link.href, "POST"); // doAjax needs to send the "confirm" field
        }
        return false;
    }
    </script>
  </body>

</html>