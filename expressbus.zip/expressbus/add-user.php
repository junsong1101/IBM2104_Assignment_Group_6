<?php
    if(!isset($_SESSION)){
        session_start();
        include('check-login.php');
    }

    if(isset($_POST['name']) && isset($_POST['email']) && isset($_POST['type']) && isset($_POST['number']) && isset($_FILES['image']['name'])){
        
        include('database-config.php');
        $name = mysqli_real_escape_string($conn, $_POST['name']);
        $type = mysqli_real_escape_string($conn, $_POST['type']);
        $email = mysqli_real_escape_string($conn, $_POST['email']);
        $number = mysqli_real_escape_string($conn, $_POST['number']);
        
        if(!is_numeric($numer) && strlen($number) < 10 && strlen($number) > 11){
            header("Location: add-user.php?success=1");
            exit();
        }
        include('image-config.php');

        // Check extension
        if(in_array($imageFileType,$extensions_arr) ){

            include('image-encode.php');

            $sql = "INSERT INTO tbl_user SET 
            user_name = '$name',
            user_type = '$type',
            user_email = '$email',
            user_contact = '$number',
            user_profile_image = '".$image."'";

            if(mysqli_query($conn, $sql)){
                // Upload file
                move_uploaded_file($_FILES['image']['tmp_name'],$target_dir.$file);
                $conn->close();
                header("Location: user-control.php?success=1");
                exit();
            }else{
                die('error' . mysqli_error($conn));
                $conn->close();
                header("Location: user-control.php?success=2");
                exit();
            }
        }
        else{
            echo $_FILES['image']['name'];
        }
    }
?>
<!doctype html>
<html lang="en">

  <head>
    <title>Admin &mdash; Add User</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700;900&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="fonts/icomoon/style.css">

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.fancybox.min.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">
    <link rel="stylesheet" href="css/aos.css">

    <!-- MAIN CSS -->
    <link rel="stylesheet" href="css/style.css">
      <style>
          .submitbtn {
              background-color: #ffffff; 
              float: left;
              width: 100%;
              border: 2px solid #007bff;
              color: #007bff;
              margin: 8px 0;
              padding: 14px 20px;
          }
          .submitbtn:hover{
              background-color: #007bff;
              color: #ffffff;
          }.form-control{
              margin: 5px 0;
          }
      </style>
  </head>

  <body>

    
    <div class="site-wrap" id="home-section">

      <div class="site-mobile-menu site-navbar-target">
        <div class="site-mobile-menu-header">
          <div class="site-mobile-menu-close mt-3">
            <span class="icon-close2 js-menu-toggle"></span>
          </div>
        </div>
        <div class="site-mobile-menu-body"></div>
      </div>



<?php
        include('header.php');
?> 
        
        <h1 style="text-align: center;">Add User</h1>
    <section class="ftco-section">
    	<div class="container">
            <form action="add-user.php" method="post" autocomplete="off" enctype="multipart/form-data">
                <div class="row">
                    <div class="col-lg-6 mb-5 ftco-animate">
                        <div class="imgcontainer">
                          <img class="image" id="upload" src="images/defaultImg.png" style="width:100%;" >
                          <span id="spnFilePath"></span>
                          <input style="margin-top:20px;" type="file" onchange="readURL(this)" name="image" required>    
                        </div>
                    </div>
                    <div class="col-lg-6  pl-md-5 ftco-animate">
                            <div class="container" style="padding:16px;">
                              <label for="name"><b>Name</b></label>
                              <input type="text" name="name" class="form-control" placeholder="Enter User Name" required>

                              <label for="name"><b>Type</b></label>
                              <select name="type" class="form-control" required>
                                  <option value="customer">Customer</option>
                                  <option value="admin">Admin</option>
                              </select>

                              <label for="description"><b>Email</b></label>
                              <input type="text" class="form-control" placeholder="Enter User Email" name="email" required>

                              <label for="quantity"><b>H/P Number</b></label>
                              <input type="text"  class="form-control" placeholder="Enter H/P Number"  name="number" required>
                                
                              <button type="submit" class="submitbtn">Add User</button>
                            </div>

                    </div>
                </div>
                </form>
    	</div>
    </section>
        
<?php
    include('footer.php');
?>

    </div>
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/jquery.sticky.js"></script>
    <script src="js/jquery.waypoints.min.js"></script>
    <script src="js/jquery.animateNumber.min.js"></script>
    <script src="js/jquery.fancybox.min.js"></script>
    <script src="js/jquery.easing.1.3.js"></script>
    <script src="js/bootstrap-datepicker.min.js"></script>
    <script src="js/aos.js"></script>
    <script src="js/main.js"></script>
    <script type="text/javascript">
    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $('#upload')
                    .attr('src', e.target.result)
            };

            reader.readAsDataURL(input.files[0]);
        }
    }
    </script>
  </body>
</html>