<?php
    if(!isset($_SESSION)){
        session_start();
        include('check-login.php');
    }

    if(isset($_POST['bus_id']) && isset($_POST['dtime']) && isset($_POST['atime']) && isset($_POST['dloc']) && isset($_POST['aloc']) && isset($_POST['fare']) && isset($_POST['date'])){
        
        include('database-config.php');
        $busid = mysqli_real_escape_string($conn, $_POST['bus_id']);
        $dtime = mysqli_real_escape_string($conn, $_POST['dtime']);
        $atime = mysqli_real_escape_string($conn, $_POST['atime']);
        $dloc = mysqli_real_escape_string($conn, $_POST['dloc']);
        $aloc = mysqli_real_escape_string($conn, $_POST['aloc']);
        $date = mysqli_real_escape_string($conn, $_POST['date']);
        $fare = mysqli_real_escape_string($conn, $_POST['fare']);
        
        $sql = "SELECT * FROM tbl_bus WHERE bus_id = '$busid'";
        $result = mysqli_query($conn, $sql);
        if (mysqli_num_rows($result) >0){
            while ($rows = mysqli_fetch_assoc($result)){
                $seats = $rows['bus_seats'];
            }
        }
        
        $sql = "INSERT INTO tbl_trip SET 
        bus_id = '$busid',
        availability = 'y',
        available_seats = '$seats',
        departure_time = '$dtime',
        arrival_time = '$atime',
        departure_location = '$dloc',
        arrival_location = '$aloc',
        trip_date = '$date',
        trip_fare = '$fare'";

        if(mysqli_query($conn, $sql)){
            $conn->close();
            header("Location: trip-control.php?success=1");
            exit();
        }else{
            die('error' . mysqli_error($conn));
            $conn->close();
            header("Location: trip-control.php?success=2");
            exit();
        }
    }
?>
<!doctype html>
<html lang="en">

  <head>
    <title>Admin &mdash; Add Trip</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700;900&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="fonts/icomoon/style.css">

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.fancybox.min.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">
    <link rel="stylesheet" href="css/aos.css">

    <!-- MAIN CSS -->
    <link rel="stylesheet" href="css/style.css">
      <style>
          .submitbtn {
              background-color: #ffffff; 
              float: left;
              width: 100%;
              border: 2px solid #007bff;
              color: #007bff;
              margin: 8px 0;
              padding: 14px 20px;
          }
          .submitbtn:hover{
              background-color: #007bff;
              color: #ffffff;
          }.form-control{
              margin: 5px 0;
          }
          form{
              width: 50%;
              margin: auto;
          }
      </style>
  </head>

  <body>

    
    <div class="site-wrap" id="home-section">

      <div class="site-mobile-menu site-navbar-target">
        <div class="site-mobile-menu-header">
          <div class="site-mobile-menu-close mt-3">
            <span class="icon-close2 js-menu-toggle"></span>
          </div>
        </div>
        <div class="site-mobile-menu-body"></div>
      </div>



<?php
        include('header.php');
?> 
        
    <h1 style="text-align: center;">Add Trip</h1>
    <section class="ftco-section">
    	<div class="container">
            <form action="add-trip.php" method="post" autocomplete="off" enctype="multipart/form-data">
                <div class="container" style="padding:16px;">
                  <label for="id"><b>Bus ID</b></label>
                  <select name="bus_id" class="form-control" required>
                  <?php 
                    include('database-config.php');
                    $sql = "SELECT * FROM tbl_bus";
                    $result = mysqli_query($conn, $sql);
                    if(mysqli_num_rows($result) > 0){
                        while($row = mysqli_fetch_assoc($result)){
                  ?>
                            <option value="<?php echo $row['bus_id']?>"><?php echo $row['bus_id']?></option>
                  <?php
                        }
                    }
                    mysqli_close($conn);
                  ?>              
                  </select>
                  <div class="row">
                      <div class="col-md-6">
                        <label for="departure_time"><b>Departure Time</b></label>
                          <input type="time" name="dtime" class="form-control" required>
                      </div>
                      <div class="col-md-6">
                        <label for="arrival_time"><b>Arrival Time</b></label>
                          <input type="time" name="atime" class="form-control" required>
                      </div>                        
                  </div>  
                  <label for="departure_loc"><b>Departure Location</b></label>
                  <select name="dloc" class="form-control" required>
                  <?php 
                      include('database-config.php');
                      $sql2 = "SELECT * FROM tbl_area_location WHERE status = 1";
                      $result2 = mysqli_query($conn, $sql2);
                      if(mysqli_num_rows($result2) > 0){
                          while ($row = mysqli_fetch_assoc($result2)){
                  ?>
                              <option value="<?php echo $row['area_name']; ?>"><?php echo $row['area_name']; ?></option>
                  <?php
                          }
                      }
                  ?>
                  </select>
                    
                  <label for="arrival_loc"><b>Arrival Location</b></label>
                  <select name="aloc" class="form-control" required>
                  <?php 
                      include('database-config.php');
                      $sql2 = "SELECT * FROM tbl_area_location WHERE status = 1";
                      $result2 = mysqli_query($conn, $sql2);
                      if(mysqli_num_rows($result2) > 0){
                          while ($row = mysqli_fetch_assoc($result2)){
                  ?>
                              <option value="<?php echo $row['area_name']; ?>"><?php echo $row['area_name']; ?></option>
                  <?php
                          }
                      }
                  ?>
                  </select>
                    
                  <label for="fare"><b>Trip Date</b></label>
                  <input type="text" name="date" class="form-control datepicker px-3" required>
                    
                  <label for="fare"><b>Trip Fare</b></label>
                  <input type="text" name="fare" class="form-control" placeholder="Enter trip fare" required>

                  <button type="submit" class="submitbtn">Add Trip</button>
                </div>
            </form>
    	</div>
    </section>
        
<?php
    include('footer.php');
?>

    </div>
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/jquery.sticky.js"></script>
    <script src="js/jquery.waypoints.min.js"></script>
    <script src="js/jquery.animateNumber.min.js"></script>
    <script src="js/jquery.fancybox.min.js"></script>
    <script src="js/jquery.easing.1.3.js"></script>
    <script src="js/bootstrap-datepicker.min.js"></script>
    <script src="js/aos.js"></script>
    <script src="js/main.js"></script>
    <script type="text/javascript">
    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $('#upload')
                    .attr('src', e.target.result)
            };

            reader.readAsDataURL(input.files[0]);
        }
    }
    </script>
  </body>
</html>